package com.example.abcDemo4.calendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

@WebServlet(name = "calendarServlet", value = "/calendar.do")
public class CalendarController extends HttpServlet {

  public void init() {

  }

  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType("text/text;charset=UTF-8");
    request.setCharacterEncoding("UTF-8");

    String action = request.getParameter("action");

    //來自 calendar.jsp 的showMonth請求
    if ("showMonth".equals(action)) {

      List<String> errorMessages = new LinkedList<>();
      request.setAttribute("errorMessages", errorMessages);

      /**接受請求參數-錯誤處理*/
      String monthString = request.getParameter("month").trim();
      if (monthString.length() == 0) {
        errorMessages.add("沒有輸入幾月");
      } else {
        Integer month = Integer.valueOf(monthString);
        if (month < 1) {
          errorMessages.add("想要知道" + month + "月是不可能的");
        } else {
          /**新增資料(產生月曆)*/
          CalendarService calendarService = new CalendarService();
          String calendar = calendarService.getCalendarOfMonth(month);
          request.setAttribute("month", month);
          request.setAttribute("calendar", calendar);
        }
      }
      /**新增資料完成, 轉交view*/
      String url = "/calendar.jsp";
      RequestDispatcher rd = request.getRequestDispatcher(url);
      rd.forward(request, response);
    }
  }

  public void destroy() {
  }

}
