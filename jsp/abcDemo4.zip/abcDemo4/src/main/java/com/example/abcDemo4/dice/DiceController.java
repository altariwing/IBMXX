package com.example.abcDemo4.dice;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

@WebServlet(name = "diceServlet", value = "/dice.do")
public class DiceController extends HttpServlet {

  public void init() throws ServletException {
    super.init();
  }

  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType("text/text;charset=UTF-8");
    request.setCharacterEncoding("UTF-8");

    String action = request.getParameter("action");

    //來自 diceRows.jsp 的roll請求
    if ("roll".equals(action)) {

      List<String> errorMessages = new LinkedList<>();
      request.setAttribute("errorMessages", errorMessages);

      /**接受請求參數-錯誤處理*/
      String timesString = request.getParameter("times").trim();
      if (timesString.length() == 0) {
        errorMessages.add("沒有輸入次數");
      } else {
        if (timesString.length() > 9) {
          errorMessages.add("太長, 伺服器是個人電腦體諒一下");
        } else {
          Integer times = Integer.valueOf(timesString);
          if (times < 1) {
            errorMessages.add("投擲" + times + "次是不可能的");
          } else {
            /**新增資料(丟骰子)*/
            DiceService diceService = new DiceService();
            List<DiceRowResultVO> diceResultList = diceService.rollDices(times);
            request.setAttribute("times", times);
            request.setAttribute("diceResultList", diceResultList);
          }
        }
      }
      /**新增資料完成, 轉交view*/
      String url = "/diceRows.jsp";
      RequestDispatcher rd = request.getRequestDispatcher(url);
      rd.forward(request, response);
    }
  }

  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    doPost(request, response);
  }

  public void destroy() {
    super.destroy();
  }

}
