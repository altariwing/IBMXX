package com.example.abcDemo4.dice;

import java.util.LinkedList;
import java.util.List;

public class DiceService {

  public List<DiceRowResultVO> rollDices(Integer times) {
    List<DiceRowResultVO> list = new LinkedList<>();
    int[] resultBucket = new int[6]; //隨機次數統計
    for (int i = 0; i < times; i++) {
      int rand = randomIntWithRange(1, 6);
      resultBucket[rand - 1] += 1;
    }
    for (int i = 0; i < 6; i++) {
      list.add(new DiceRowResultVO(i + 1, resultBucket[i]));
    }
    return list;
  }

  private int randomIntWithRange(int min, int max) {
    int range = Math.abs(max - min) + 1;
    return (int) (Math.random() * range) + (min <= max ? min : max);
  }

}
