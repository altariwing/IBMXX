package com.example.abcDemo4.calendar;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class CalendarService {

  public String getCalendarOfMonth(Integer month) {
    return calString(month);

  }

  private String calString(int month) {
    StringBuffer sb = new StringBuffer();

    Calendar calendar = GregorianCalendar.getInstance();
    if (month > 12) {
      calendar.add(Calendar.YEAR, month / 12);
    }
    calendar.set(Calendar.MONTH, month % 12 - 1); //JANUARY is 0
    calendar.set(Calendar.DAY_OF_MONTH, 1);

    Date date = calendar.getTime();
    LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    sb.append("<br><br><br><br>");
    sb.append(localDate.getYear() + "年" + localDate.getMonthValue() + "月<br>");
    sb.append("====================<br>");
    sb.append("日 一 二 三 四 五 六<br>");

    int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
    int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);

    for (int i = 1; i < (dayOfWeek == 7 ? 7 : dayOfWeek % 7); i++) {
      sb.append("[ ]"); //1號前的空格
    }

    for (int i = 0; i < daysInMonth; i++) {
      sb.append(String.format("%2d ", i + 1));
      if ((i + dayOfWeek) % 7 == 0) { //換行, 下一個星期
        sb.append("<br>");
      }
    }
    return sb.toString();
  }
}
