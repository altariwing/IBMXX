package com.example.abcDemo4.dice;

public class DiceRowResultVO implements java.io.Serializable {

  private Integer number;
  public Integer counts;

  public DiceRowResultVO(Integer number, Integer counts) {
    this.number = number;
    this.counts = counts;
  }

  public Integer getNumber() {
    return number;
  }

  public void setNumber(Integer number) {
    this.number = number;
  }

  public Integer getCounts() {
    return counts;
  }

  public void setCounts(Integer counts) {
    this.counts = counts;
  }

}
